#!/usr/bin/env node
import { readFileSync, writeFileSync, appendFileSync } from 'fs';
import { dirname, resolve, join } from 'path';
import { fileURLToPath } from 'url';
import { classifyRisk, classifyRiskEnhanced, extractPaths } from './risk-classifier.mjs';
import { computePromptHash, checkFailureLoop, recordFailure } from './failure-detector.mjs';
import { getOutcomeStats } from './decision-ledger.mjs';
import { atomicWriteJSON } from './atomic-write.mjs';
import { logHookError } from './error-channel.mjs';
import { loadAndValidateConfig } from './config-validator.mjs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const CONFIG_FILE = resolve(__dirname, '..', 'orchestrator.json');
const PROFILE_FILE = resolve(__dirname, '..', 'dual-brain.profile.json');
const DRIFT_STATE = resolve(__dirname, '.drift-warned');
const BURST_FILE = resolve(__dirname, '.burst-state');
const COOLDOWN_FILE = resolve(__dirname, '.recommendation-cooldowns');

// Cooldown durations per recommendation type (in milliseconds)
const COOLDOWN_MS = {
  balance_hint: 15 * 60 * 1000,    // 15 minutes — most wallpaper-prone
  tier_warning: 5 * 60 * 1000,     // 5 minutes
  outcome_advisory: 5 * 60 * 1000, // 5 minutes
  duplicate_warning: 5 * 60 * 1000, // 5 minutes
};

/**
 * Check if a recommendation type is on cooldown.
 * Returns true if the recommendation should be suppressed.
 * If not on cooldown, records the emission and returns false.
 */
function isOnCooldown(type) {
  const now = Date.now();
  let state = {};
  try { state = JSON.parse(readFileSync(COOLDOWN_FILE, 'utf8')); } catch {}

  const lastEmit = state[type] ? Date.parse(state[type]) : 0;
  const cooldownDuration = COOLDOWN_MS[type] || 5 * 60 * 1000;

  if (now - lastEmit < cooldownDuration) {
    return true; // suppress
  }

  // Record this emission
  state[type] = new Date(now).toISOString();
  try { atomicWriteJSON(COOLDOWN_FILE, state); } catch (e) { logHookError('enforce-tier', 'cooldown state write', e); }
  return false;
}

function detectBurst() {
  const now = Date.now();
  let state = { count: 0, window_start: now };
  try { state = JSON.parse(readFileSync(BURST_FILE, 'utf8')); } catch {}
  if (now - state.window_start > 90_000) state = { count: 0, window_start: now };
  state.count++;
  try { atomicWriteJSON(BURST_FILE, state); } catch (e) { logHookError('enforce-tier', 'burst state write', e); }
  return state.count >= 3;
}

function loadProfile() {
  try {
    const data = JSON.parse(readFileSync(PROFILE_FILE, 'utf8'));
    return data.active || 'auto';
  } catch { return 'auto'; }
}

const PROFILE_SETTINGS = {
  auto:            { demote_think: false, promote_execute: false, bias: 0,   mismatch_tolerance: 'strict' },
  balanced:        { demote_think: false, promote_execute: false, bias: 0,   mismatch_tolerance: 'strict' },
  'cost-saver':    { demote_think: true,  promote_execute: false, bias: -20, mismatch_tolerance: 'lenient' },
  'quality-first': { demote_think: false, promote_execute: true,  bias: 10,  mismatch_tolerance: 'paranoid' },
};

/**
 * Classify how severe a model/tier mismatch is.
 *
 * @param {string} detectedTier  - 'search' | 'execute' | 'think'
 * @param {string} actualModel   - lowercase model string from tool_input.model
 * @returns {{ severity: 'none'|'minor'|'major', reason: string, suggestedModel: string }}
 */
function classifyMismatchSeverity(detectedTier, actualModel) {
  const model = (actualModel || '').toLowerCase();

  // Canonical tier membership helpers
  const isSearchModel  = model.includes('haiku') || model.includes('gpt-4.1-mini') || model.includes('4.1-mini');
  const isExecuteModel = model.includes('sonnet') || model.includes('gpt-5.4') || model.includes('5.4');
  const isThinkModel   = model.includes('opus') || model.includes('gpt-5.5') || model.includes('5.5') ||
                         model.includes('o1') || model.includes('o3') || model.includes('o4');

  const suggestedByTier = {
    search:  'haiku (Claude) or gpt-4.1-mini (OpenAI)',
    execute: 'sonnet (Claude) or gpt-5.4 (OpenAI)',
    think:   'opus (Claude) or gpt-5.5 (OpenAI)',
  };
  const suggested = suggestedByTier[detectedTier] || 'sonnet';

  // Empty/unset model — no mismatch to classify
  if (!model || model === 'main-session') {
    return { severity: 'none', reason: 'model not specified', suggestedModel: suggested };
  }

  if (detectedTier === 'think') {
    if (isThinkModel) return { severity: 'none', reason: 'model matches think tier', suggestedModel: suggested };
    if (isExecuteModel) return {
      severity: 'minor',
      reason: `${model} is capable but not optimal for think-tier work (architecture/review/planning)`,
      suggestedModel: suggested,
    };
    // search-class model (haiku, gpt-4.1-mini) on think work → MAJOR
    return {
      severity: 'major',
      reason: `${model} is too weak for think-tier tasks (architecture decisions, security review, complex planning)`,
      suggestedModel: suggested,
    };
  }

  if (detectedTier === 'execute') {
    if (isExecuteModel) return { severity: 'none', reason: 'model matches execute tier', suggestedModel: suggested };
    if (isThinkModel) return {
      severity: 'minor',
      reason: `${model} is overkill for execute-tier work — wastes budget`,
      suggestedModel: suggested,
    };
    if (isSearchModel) return {
      severity: 'minor',
      reason: `${model} may lack capability for complex execution tasks`,
      suggestedModel: suggested,
    };
    return { severity: 'none', reason: 'model tier unclear', suggestedModel: suggested };
  }

  if (detectedTier === 'search') {
    if (isSearchModel) return { severity: 'none', reason: 'model matches search tier', suggestedModel: suggested };
    if (isExecuteModel) return {
      severity: 'minor',
      reason: `${model} is more capable than needed for search/explore tasks — consider haiku for cost savings`,
      suggestedModel: suggested,
    };
    if (isThinkModel) return {
      severity: 'major',
      reason: `${model} is massive overkill for search/grep/explore tasks — burns budget unnecessarily`,
      suggestedModel: suggested,
    };
    return { severity: 'none', reason: 'model tier unclear', suggestedModel: suggested };
  }

  return { severity: 'none', reason: 'unknown tier', suggestedModel: suggested };
}

/**
 * Given a mismatch severity and the active profile tolerance, decide whether
 * to block, warn, or allow the call.
 *
 * @param {'none'|'minor'|'major'} severity
 * @param {'lenient'|'strict'|'paranoid'} tolerance
 * @returns {'block'|'warn'|'allow'}
 */
function decideAction(severity, tolerance) {
  if (severity === 'none') return 'allow';
  if (tolerance === 'lenient') {
    // cost-saver: warn on major, ignore minor
    return severity === 'major' ? 'warn' : 'allow';
  }
  if (tolerance === 'paranoid') {
    // quality-first: block on both minor and major
    return 'block';
  }
  // strict (auto, balanced): block on major, warn on minor
  return severity === 'major' ? 'block' : 'warn';
}

function checkPricingDrift(config) {
  const verified = config.pricing_verified;
  if (!verified) return null;

  const age = Math.floor((Date.now() - Date.parse(verified)) / 86400000);
  if (age < 30) return null;

  // Rate limit: only warn once per day
  try {
    const lastWarn = readFileSync(DRIFT_STATE, 'utf8').trim();
    const today = new Date().toISOString().slice(0, 10);
    if (lastWarn === today) return null;
  } catch {}

  try {
    writeFileSync(DRIFT_STATE, new Date().toISOString().slice(0, 10));
  } catch (e) { logHookError('enforce-tier', 'drift state write', e); }

  return `**[Drift Warning]** Pricing was last verified ${age} days ago. Run \`node .claude/hooks/setup-wizard.mjs\` to update.`;
}

const SESSION_ID = process.env.CLAUDE_SESSION_ID || process.ppid?.toString() || null;

function logRecommendation(event) {
  const logFile = join(__dirname, `usage-${new Date().toISOString().slice(0, 10)}.jsonl`);
  const profileName = event.profile || 'balanced';
  const entryObj = {
    timestamp: new Date().toISOString(),
    type: 'tier_recommendation',
    detected_tier: event.tier,
    recommended_model: event.recommended,
    actual_model: event.actual,
    prompt_hash: event.promptHash,
    followed: event.followed,
    session_id: SESSION_ID,
    profile: profileName,
  };
  const entry = JSON.stringify(entryObj);
  try {
    appendFileSync(logFile, entry + '\n');
  } catch {}

  // Sync summary update (for dupe detection on next call)
  try {
    const today = new Date().toISOString().slice(0, 10);
    const summaryFile = join(__dirname, `usage-summary-${today}.json`);
    let summary;
    try { summary = JSON.parse(readFileSync(summaryFile, 'utf8')); } catch { summary = { version: 1, recent_hashes: [] }; }
    if (event.promptHash) {
      summary.recent_hashes = summary.recent_hashes || [];
      summary.recent_hashes.push({ hash: event.promptHash, ts: entryObj.timestamp });
      const threeMinAgo = Date.now() - 3 * 60 * 1000;
      summary.recent_hashes = summary.recent_hashes.filter(h => Date.parse(h.ts) >= threeMinAgo);
    }
    summary.updated_at = new Date().toISOString();
    atomicWriteJSON(summaryFile, summary);
  } catch (e) { logHookError('enforce-tier', 'summary update', e); }

  // Sync ledger write (append-only, fast)
  try {
    const ledgerEntry = JSON.stringify({
      type: 'decision',
      id: entryObj.timestamp.replace(/\W/g, '').slice(-12),
      timestamp: entryObj.timestamp,
      session_id: SESSION_ID,
      profile: profileName,
      tier: event.tier,
      provider: detectProvider(event.actual),
      model: event.actual || 'unknown',
      recommended_model: event.recommended,
      followed: event.followed,
      prompt_hash: event.promptHash,
    });
    appendFileSync(join(__dirname, 'decision-ledger.jsonl'), ledgerEntry + '\n');
  } catch (e) { logHookError('enforce-tier', 'decision ledger append', e); }
}

function checkDuplicate(promptHash) {
  // Try summary checkpoint first (O(1))
  try {
    const summaryPath = join(__dirname, `usage-summary-${new Date().toISOString().slice(0, 10)}.json`);
    const summary = JSON.parse(readFileSync(summaryPath, 'utf8'));
    const threeMinAgo = Date.now() - 3 * 60 * 1000;
    const match = (summary.recent_hashes || []).find(
      h => h.hash === promptHash && Date.parse(h.ts) >= threeMinAgo
    );
    if (match) return { timestamp: match.ts, prompt_hash: promptHash };
  } catch {}

  // Fallback: scan log
  const logFile = join(__dirname, `usage-${new Date().toISOString().slice(0, 10)}.jsonl`);
  try {
    const lines = readFileSync(logFile, 'utf8').split('\n').filter(Boolean);
    const threeMinAgo = Date.now() - 3 * 60 * 1000;
    for (const line of lines) {
      try {
        const entry = JSON.parse(line);
        if (entry.type === 'tier_recommendation' &&
            entry.prompt_hash === promptHash &&
            Date.parse(entry.timestamp) > threeMinAgo) {
          return entry;
        }
      } catch {}
    }
  } catch {}
  return null;
}

function detectProvider(model) {
  if (!model || model === 'main-session') return 'claude';
  const m = String(model).toLowerCase();
  if (m.includes('gpt') || m.includes('o1') || m.includes('o3') || m.includes('o4')) return 'openai';
  if (m.includes('opus') || m.includes('sonnet') || m.includes('haiku') || m.includes('claude')) return 'claude';
  return 'claude';
}

function quickPressureCheck(tier) {
  // Try summary checkpoint first (O(1))
  try {
    const today = new Date().toISOString().slice(0, 10);
    const summaryPath = join(__dirname, `usage-summary-${today}.json`);
    const summary = JSON.parse(readFileSync(summaryPath, 'utf8'));
    const cutoff = Date.now() - 5 * 60 * 60 * 1000;
    const claudeTs = (summary.pressure?.claude?.[tier] || []).filter(t => Date.parse(t) >= cutoff);
    const openaiTs = (summary.pressure?.openai?.[tier] || []).filter(t => Date.parse(t) >= cutoff);
    return { claudeCalls: claudeTs.length, openaiCalls: openaiTs.length };
  } catch {}

  // Fallback: scan log
  try {
    const today = new Date().toISOString().slice(0, 10);
    const logFile = join(__dirname, `usage-${today}.jsonl`);
    const lines = readFileSync(logFile, 'utf8').split('\n').filter(Boolean);
    const fiveHoursAgo = Date.now() - 5 * 60 * 60 * 1000;
    let claudeCalls = 0, openaiCalls = 0;
    for (const line of lines) {
      try {
        const entry = JSON.parse(line);
        if (Date.parse(entry.timestamp) < fiveHoursAgo) continue;
        if (entry.tier !== tier) continue;
        const provider = entry.provider || (entry.model?.includes('gpt') ? 'openai' : 'claude');
        if (provider === 'claude') claudeCalls++;
        else openaiCalls++;
      } catch {}
    }
    return { claudeCalls, openaiCalls };
  } catch {
    return null;
  }
}

const SEARCH_WORDS = /\b(explore|search|find|grep|locate|where\s+is|list\s+files|read[-\s]?only|lookup|scan)\b/i;
const THINK_WORDS = /\b(plan|design|architect|review|audit|security|code[-\s]?review|threat[-\s]?model|complex[-\s]?debug)\b/i;

function preferredModel(config, tier) {
  const models = config?.subscriptions?.claude?.models ?? {};
  for (const [name, meta] of Object.entries(models)) {
    if (meta?.tier === tier) return name;
  }
  return null;
}

try {
  const input = JSON.parse(readFileSync('/dev/stdin', 'utf8'));

  if (input.tool_name !== 'Agent') {
    process.stdout.write('{}');
    process.exit(0);
  }

  const ti = input.tool_input || {};
  const text = `${ti.description || ''} ${ti.prompt || ''}`.toLowerCase();
  const subType = (ti.subagent_type || '').toLowerCase();
  const currentModel = (ti.model || '').toLowerCase();

  // Compute prompt hash early for duplicate detection and logging
  const promptHash = computePromptHash(ti);

  // Burst detection — suppress noise during wave launches (3+ agents in 90s)
  const burstMode = detectBurst();

  // Check for duplicate agent dispatch before tier classification
  const duplicate = checkDuplicate(promptHash);
  let duplicateWarning = null;
  if (duplicate && !isOnCooldown('duplicate_warning')) {
    const minutesAgo = Math.round((Date.now() - Date.parse(duplicate.timestamp)) / 60000);
    if (burstMode) {
      // In burst mode, only warn on exact hash matches (same description+prompt)
      if (duplicate.prompt_hash === promptHash) {
        duplicateWarning = `Heads up — a similar task ran ${minutesAgo} minute${minutesAgo !== 1 ? 's' : ''} ago (wave detected). Reuse that result if the scope hasn't changed.`;
      }
      // Otherwise suppress — similar-but-different agents in a wave are expected
    } else {
      duplicateWarning = `Heads up — a similar task ran ${minutesAgo} minute${minutesAgo !== 1 ? 's' : ''} ago. Reuse that result if the scope hasn't changed.`;
    }
  }

  let config;
  try {
    const result = loadAndValidateConfig(CONFIG_FILE);
    config = result.config;
  } catch {
    process.stdout.write('{}');
    process.exit(0);
  }

  const driftWarning = checkPricingDrift(config);

  // Build flat model intelligence lookup from subscriptions (merged in v4.2.0)
  const intelligence = {};
  for (const provider of Object.values(config.subscriptions || {})) {
    for (const [name, meta] of Object.entries(provider.models || {})) {
      intelligence[name] = meta;
    }
  }
  const defaults = config.routing_rules?.subagent_defaults || {};
  let tier = null;

  for (const [key, val] of Object.entries(defaults)) {
    if (subType === key.toLowerCase()) { tier = val; break; }
  }

  // Balance hint — populated after tier is fully resolved
  let balanceHint = null;
  // Outcome advisory — populated after tier is fully resolved
  let outcomeAdvisory = null;

  // Helper to prepend optional warnings (duplicate + drift + balance + outcome + auto) before a message
  const prependWarnings = (msg) => {
    const parts = [duplicateWarning, driftWarning, failureMessage, msg, autoStatus, balanceHint, outcomeAdvisory].filter(Boolean);
    return parts.join('\n\n');
  };

  // Load profile early so all log entries can reference it
  const profileName = loadProfile();
  const profileSettings = PROFILE_SETTINGS[profileName] || PROFILE_SETTINGS.balanced;

  // Multi-tier detection — only when tier is not already resolved from subagent_defaults
  if (!tier) {
    const hasThink = THINK_WORDS.test(text);
    const hasExecute = /\b(edit|write|fix|implement|modify|refactor|delete|commit|test|build|run|add|update|create)\b/i.test(text);
    const hasSearch = SEARCH_WORDS.test(text);

    const detectedTiers = [
      hasSearch && 'search',
      hasExecute && 'execute',
      hasThink && 'think',
    ].filter(Boolean);

    if (detectedTiers.length > 1) {
      const splitMsg = `This spans ${detectedTiers.join(' + ')} work. Consider splitting: ` +
        (hasSearch ? 'search first (haiku), ' : '') +
        (hasExecute ? 'then execute edits (sonnet), ' : '') +
        (hasThink ? 'keep planning/review on the main session (opus).' : '');
      const fullMsg = prependWarnings(splitMsg.replace(/, $/, '.'));
      logRecommendation({
        tier: detectedTiers.join('+'),
        recommended: null,
        actual: currentModel,
        promptHash,
        followed: false,
        profile: profileName,
      });
      process.stdout.write(JSON.stringify({ systemMessage: fullMsg }));
      process.exit(0);
    }

    if (THINK_WORDS.test(text)) tier = 'think';
    else if (/\b(edit|write|fix|implement|modify|refactor|delete|commit|test|build|run|add|update|create)\b/i.test(text)) tier = 'execute';
    else if (SEARCH_WORDS.test(text)) tier = 'search';
    else tier = 'execute';
  }

  // Risk classification from file paths in description
  // Use enhanced classifier (git churn + history) when a single file path is available,
  // fall back to static classifier for multi-path or missing cases.
  const filePaths = extractPaths(ti.description || '');
  let riskResult;
  let riskEscalationReason = null;

  if (filePaths.length === 1) {
    try {
      const enhanced = classifyRiskEnhanced(filePaths[0]);
      riskResult = { level: enhanced.risk, reason: filePaths[0] };
      // Build human-readable escalation reason if empirical data bumped the risk
      if (enhanced.basis === 'churn' || enhanced.basis === 'churn+history') {
        riskEscalationReason = `Risk escalated: high git churn (${enhanced.details.churn_commits} commits in 30 days)`;
      }
      if (enhanced.basis === 'history' || enhanced.basis === 'churn+history') {
        const historyNote = `${enhanced.details.history_success_rate}% failure rate on this file path`;
        riskEscalationReason = riskEscalationReason
          ? `${riskEscalationReason}; ${historyNote}`
          : `Risk escalated: ${historyNote}`;
      }
    } catch {
      riskResult = classifyRisk(filePaths);
    }
  } else {
    riskResult = classifyRisk(filePaths);
  }

  let autoStatus = null;

  // Bias high/critical risk toward think tier
  if ((riskResult.level === 'critical' || riskResult.level === 'high') && tier !== 'think') {
    tier = 'think';
    const baseMsg = riskResult.level === 'critical'
      ? `This touches ${String(riskResult.reason).split(':')[0].toLowerCase()} — recommending dual-brain review for safety.`
      : `Promoting to think tier — this is ${String(riskResult.reason).split(':')[0].toLowerCase()}.`;
    autoStatus = riskEscalationReason ? `${baseMsg} ${riskEscalationReason}.` : baseMsg;
  }

  // Failure loop detection
  const failureCheck = checkFailureLoop(promptHash);
  let failureMessage = null;
  if (failureCheck.isLoop) {
    if (failureCheck.suggestion === 'promote_tier' && tier === 'execute') {
      tier = 'think';
      autoStatus = 'Escalating to think tier — this has failed before, let\'s take a different approach.';
    } else if (failureCheck.suggestion === 'escalate_to_dual_brain') {
      autoStatus = 'Repeated failures detected — recommending dual-brain review to diagnose the issue.';
    }
    failureMessage = `⚠️ This has failed ${failureCheck.count} times in the last 2 hours. Consider a dual-brain think session to diagnose the root cause.`;
  }

  // Apply profile-driven tier adjustments
  if (profileSettings.demote_think && tier === 'think' && !THINK_WORDS.test(text)) {
    tier = 'execute';
  }
  if (profileSettings.promote_execute && tier === 'execute' && THINK_WORDS.test(text)) {
    tier = 'think';
  }

  // Compute balance hint now that tier is resolved
  // In burst mode, skip balance hints — one hint per wave is enough
  // Balance hints have a 15-minute cooldown (most wallpaper-prone)
  if (!burstMode && !isOnCooldown('balance_hint')) {
    const currentProvider = detectProvider(currentModel);
    if (currentProvider === 'claude') {
      const balance = quickPressureCheck(tier);
      const biasThreshold = profileSettings.bias >= 0 ? 10 : 20;
      if (balance && balance.claudeCalls > balance.openaiCalls * 2 && balance.claudeCalls > biasThreshold) {
        const dispatchModel = tier === 'think' ? 'gpt-5.5' : tier === 'execute' ? 'gpt-5.4' : 'gpt-4.1-mini';
        balanceHint = `\n\n💡 Claude is handling most work right now (${balance.claudeCalls} ${tier} calls vs ${balance.openaiCalls} GPT). For isolated tasks, consider routing to GPT to balance subscriptions.`;
      }
    }
  }

  // Outcome stats advisory — best-effort, suppressed in burst mode and on cooldown
  if (!burstMode && !isOnCooldown('outcome_advisory')) {
    try {
      const stats = getOutcomeStats();
      const tierIssue = stats.underperforming.find(u => u.tier === tier);
      if (tierIssue) {
        outcomeAdvisory = `Heads up — ${tierIssue.tier} tasks have been struggling lately (${tierIssue.rate}% success over ${tierIssue.total} recent outcomes). Consider escalating to a higher tier.`;
      }
    } catch {}
  }

  const expected = preferredModel(config, tier);

  // ── Mismatch severity classification (v4.5.0) ──────────────────────────────
  const mismatch = classifyMismatchSeverity(tier, currentModel);
  const tolerance = profileSettings.mismatch_tolerance || 'strict';
  const action = decideAction(mismatch.severity, tolerance);

  const followed = action === 'allow';
  logRecommendation({
    tier,
    recommended: expected,
    actual: currentModel,
    promptHash,
    followed,
    profile: profileName,
  });

  if (action === 'allow') {
    // Model is fine — emit only ambient warnings (duplicate, drift, failure, balance, outcome)
    const onlyWarnings = [duplicateWarning, driftWarning, failureMessage, autoStatus, balanceHint, outcomeAdvisory].filter(Boolean).join('\n\n');
    if (onlyWarnings) {
      process.stdout.write(JSON.stringify({ systemMessage: onlyWarnings }));
    } else {
      process.stdout.write('{}');
    }
    process.exit(0);
  }

  // On cooldown — emit only ambient warnings (don't repeat tier advice)
  if (isOnCooldown('tier_warning')) {
    const onlyWarnings = [duplicateWarning, driftWarning, failureMessage, autoStatus, balanceHint, outcomeAdvisory].filter(Boolean).join('\n\n');
    process.stdout.write(JSON.stringify(onlyWarnings ? { systemMessage: onlyWarnings } : {}));
    process.exit(0);
  }

  // Build the tier advice message, calibrated to severity
  const bestFor = intelligence[expected]?.best_for;
  const bestForSuffix = bestFor ? ` (best for: ${bestFor})` : '';

  let tierMsg;
  if (action === 'block') {
    // Strongest available signal — Claude Code PreToolUse hooks use systemMessage
    // (no formal "block" key in the hook contract), so we make the message impossible to ignore.
    tierMsg =
      `⛔ BLOCKED: ${mismatch.reason}.\n` +
      `Resubmit with model: '${mismatch.suggestedModel}'.\n` +
      `This ${tier}-tier task requires at least ${tier === 'think' ? 'execute' : 'search'}-tier capability or higher.\n` +
      `Correct model${bestForSuffix}: ${expected || mismatch.suggestedModel}`;
  } else {
    // warn
    const savingsHint =
      tier === 'search' ? 'Haiku is 19x cheaper than Opus for read-only lookups.' :
      tier === 'execute' ? 'Sonnet is 5x cheaper than Opus for implementation work.' :
      `${expected || 'opus'} is the recommended model for think-tier work.`;
    tierMsg =
      `⚠️ Model mismatch (${mismatch.severity}): ${mismatch.reason}. ` +
      `Suggested: ${mismatch.suggestedModel}${bestForSuffix}. ${savingsHint}`;
  }

  process.stdout.write(JSON.stringify({ systemMessage: prependWarnings(tierMsg) }));
} catch (err) {
  process.stdout.write(JSON.stringify({
    systemMessage: `[Tier Enforcer] Config error: ${err?.message?.slice(0, 100) || 'unknown'}. Falling back to main-session judgment.`
  }));
}
process.exit(0);
